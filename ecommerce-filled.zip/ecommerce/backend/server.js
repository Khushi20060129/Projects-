const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(morgan('dev'));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', credentials: true }));

// Health
app.get('/api/health', (_req, res) => res.json({ ok: true }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));

// DB + Server
const fs = require('fs');
const path = require('path');
const Product = require('./models/Product');

const PORT = process.env.PORT || 5000;
mongoose
  .connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('MongoDB connected');
    // 🔰 Auto-seed once: only if products collection is empty
    const count = await Product.countDocuments();
    if (count === 0) {
      try {
        const data = fs.readFileSync(path.join(__dirname, 'seeds', 'products.json'), 'utf-8');
        const items = JSON.parse(data);
        await Product.insertMany(items);
        console.log(`Seeded ${items.length} products.`);
      } catch (e) {
        console.log('Seed error:', e.message);
      }
    }
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err) => console.error('Mongo error:', err.message));
