const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: '' },
    price: { type: Number, required: true, min: 0 },
    image: { type: String, default: '' },
    stock: { type: Number, default: 0 },
    category: { type: String, default: 'general' }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Product', productSchema);
