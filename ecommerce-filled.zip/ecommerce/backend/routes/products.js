const router = require('express').Router();
const Product = require('../models/Product');
const { auth, admin } = require('../middleware/auth');

// List products (public)
router.get('/', async (_req, res) => {
  const items = await Product.find().sort({ createdAt: -1 });
  res.json(items);
});

// Single product (public)
router.get('/:id', async (req, res) => {
  const item = await Product.findById(req.params.id);
  if (!item) return res.status(404).json({ message: 'Not found' });
  res.json(item);
});

// Create (admin)
router.post('/', auth, admin, async (req, res) => {
  const item = await Product.create(req.body);
  res.status(201).json(item);
});

// Update (admin)
router.put('/:id', auth, admin, async (req, res) => {
  const item = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(item);
});

// Delete (admin)
router.delete('/:id', auth, admin, async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
