import { useEffect, useState } from 'react';
import { api } from '../api';
import ProductCard from '../components/ProductCard';
import { cart } from '../store/cart';

export default function Home(){
  const [items, setItems] = useState([]);
  useEffect(()=>{ api.get('/products').then(r=> setItems(r.data)); },[]);
  return (
    <div className="container">
      <h2 style={{ margin:'16px 0' }}>Featured Products</h2>
      <div className="grid">
        {items.map(p => <ProductCard key={p._id} p={p} onAdd={(x)=>{ cart.add(x); alert('Added to cart'); }} />)}
      </div>
    </div>
  );
}
