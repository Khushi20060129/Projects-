import { cart } from '../store/cart';
import { useSyncExternalStore } from 'react';

function useCart(){
  return useSyncExternalStore(
    (cb)=>{ cart._cb = cb; return ()=> (cart._cb = null); },
    ()=> cart.items
  );
}

const _add = cart.add.bind(cart); cart.add = (p)=>{ _add(p); cart._cb && cart._cb(); };
const _remove = cart.remove.bind(cart); cart.remove = (id)=>{ _remove(id); cart._cb && cart._cb(); };

export default function Cart(){
  const items = useCart();
  const total = cart.total();
  return (
    <div className="container">
      <h2>Cart</h2>
      {items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <div>
          {items.map(i => (
            <div key={i._id} style={{ display:'flex', alignItems:'center', gap:12, padding:'8px 0', borderBottom:'1px solid #eee' }}>
              <img src={i.image || 'https://picsum.photos/100'} alt={i.title} width="72" height="72" style={{ borderRadius:8, objectFit:'cover' }} />
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:600 }}>{i.title}</div>
                <div>Qty: {i.qty}</div>
              </div>
              <div>₹ {i.price * i.qty}</div>
              <button className="btn" onClick={()=> cart.remove(i._id)} style={{ background:'#ef4444' }}>Remove</button>
            </div>
          ))}
          <h3>Total: ₹ {total}</h3>
          <button className="btn">Checkout (demo)</button>
        </div>
      )}
    </div>
  );
}
