import { useState } from 'react';
import { api } from '../api';
import { auth } from '../store/auth';

export default function Login(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');

  const submit = async (e)=>{
    e.preventDefault(); setErr('');
    try {
      const { data } = await api.post('/auth/login', { email, password });
      auth.login(data); location.href='/';
    } catch (e) { setErr(e.response?.data?.message || 'Login failed'); }
  };

  return (
    <div className="container">
      <h2>Login</h2>
      <form className="form" onSubmit={submit}>
        <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        {err && <div style={{ color:'crimson' }}>{err}</div>}
        <button className="btn">Sign in</button>
      </form>
    </div>
  );
}
