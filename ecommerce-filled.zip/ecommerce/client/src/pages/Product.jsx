import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api';
import { cart } from '../store/cart';

export default function Product(){
  const { id } = useParams();
  const [p, setP] = useState(null);
  useEffect(()=>{ api.get(`/products/${id}`).then(r=> setP(r.data)); }, [id]);
  if(!p) return <div className="container">Loading...</div>;
  return (
    <div className="container">
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
        <img src={p.image || 'https://picsum.photos/800/600'} alt={p.title} style={{ width:'100%', borderRadius:12 }} />
        <div>
          <h2>{p.title}</h2>
          <p>{p.description}</p>
          <div className="price">₹ {p.price}</div>
          <button className="btn" onClick={()=>{ cart.add(p); alert('Added to cart'); }}>Add to Cart</button>
        </div>
      </div>
    </div>
  );
}
