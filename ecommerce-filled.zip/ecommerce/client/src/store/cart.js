export const cart = {
  items: [],
  add(product){
    const found = this.items.find(i => i._id === product._id);
    if(found) found.qty += 1; else this.items.push({ ...product, qty: 1 });
  },
  remove(id){ this.items = this.items.filter(i => i._id !== id); },
  total(){ return this.items.reduce((s, i) => s + i.price * i.qty, 0); }
};
