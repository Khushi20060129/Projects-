import { setToken } from '../api';

export const auth = {
  user: null,
  token: localStorage.getItem('token') || null,
  init(){ if(this.token){ setToken(this.token); } },
  login(data){ this.user = data.user; this.token = data.token; localStorage.setItem('token', data.token); setToken(data.token); },
  logout(){ this.user = null; this.token = null; localStorage.removeItem('token'); setToken(null); }
};
