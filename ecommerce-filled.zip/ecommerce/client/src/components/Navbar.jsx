import { Link, NavLink } from 'react-router-dom';
import { auth } from '../store/auth';

export default function Navbar(){
  const logged = !!auth.token;
  return (
    <div className="nav">
      <div className="wrap container">
        <Link to="/" className="brand">E‑Shop</Link>
        <div style={{ display:'flex', gap:12, alignItems:'center' }}>
          <NavLink to="/" style={{ color:'#fff', textDecoration:'none' }}>Home</NavLink>
          <NavLink to="/cart" style={{ color:'#fff', textDecoration:'none' }}>Cart</NavLink>
          {logged ? (
            <button className="btn" onClick={()=>{auth.logout(); location.href='/'}}>Logout</button>
          ) : (
            <>
              <NavLink to="/login" className="btn">Login</NavLink>
              <NavLink to="/register" className="btn" style={{ background:'#374151' }}>Sign Up</NavLink>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
