import { Link } from 'react-router-dom';

export default function ProductCard({ p, onAdd }){
  return (
    <div className="card">
      <img src={p.image || 'https://picsum.photos/400/300'} alt={p.title} />
      <div className="body">
        <div className="header"><span className="badge">{p.category || 'general'}</span></div>
        <h4>{p.title}</h4>
        <div className="price">₹ {p.price}</div>
        <div style={{ display:'flex', gap:8, marginTop:8}}>
          <button className="btn" onClick={()=>onAdd?.(p)}>Add to Cart</button>
          <Link className="btn" to={`/product/${p._id}`} style={{ background:'#111827' }}>Details</Link>
        </div>
      </div>
    </div>
  );
}
