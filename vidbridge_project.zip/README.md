# VidBridge — Secure Video Conferencing (WebRTC + MERN)

One-command setup with Docker. Features:

- Secure P2P video calls (WebRTC DTLS-SRTP)
- Optional End-to-End Encryption (E2EE) via Insertable Streams (shared room key)
- Screen sharing
- Chat (WebRTC DataChannel)
- Meeting scheduling + downloadable ICS calendar invite
- Recording (client-side) + upload to server + playback page
- MongoDB for meetings & recordings metadata
- Socket.IO signaling server
- React client (Vite) served via Nginx

## Quick Start (recommended)

1. Install **Docker** + **Docker Compose**.
2. Copy `.env.example` to `.env` and adjust values if needed.
3. Run:
   ```bash
   docker compose up --build
   ```
4. Open http://localhost:5173

## Manual (without Docker)

- Start MongoDB locally (default mongodb://mongo:27017 in Docker; change MONGO_URI in `.env`).
- `cd server && npm i && npm run dev`
- `cd client && npm i && npm run dev`

## Notes

- E2EE: Enter a shared **Room Key** in the UI (same for all peers). If unsupported, app falls back to standard WebRTC.
- Google Calendar: We provide ICS file + a "Add to Google Calendar" prefilled link. Full OAuth flow is optional and requires credentials.
- Recording: Uses MediaRecorder in browser, then uploads WEBM to the server. Playback is available at `/play/:recordingId`.
