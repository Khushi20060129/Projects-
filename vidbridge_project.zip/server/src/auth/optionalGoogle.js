export function googlePrefilledLink({ title, startISO, durationMins, details, url }) {
  // Simple prefilled link (no OAuth): opens Google Calendar event creation
  const start = new Date(startISO).toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const end = new Date(new Date(startISO).getTime() + (durationMins || 60)*60000).toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: title,
    details: details || "",
    location: url || "Online",
    dates: `${start}/${end}`
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}
