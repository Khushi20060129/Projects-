import mongoose from "mongoose";

const MeetingSchema = new mongoose.Schema({
  title: { type: String, required: true },
  roomId: { type: String, required: true, unique: true },
  hostName: { type: String, required: true },
  scheduledAt: { type: Date, required: true },
  durationMins: { type: Number, default: 60 },
  roomKeyHint: { type: String }, // optional E2EE hint
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model("Meeting", MeetingSchema);
