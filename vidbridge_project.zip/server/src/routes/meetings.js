import express from "express";
import Meeting from "../models/Meeting.js";
import { eventToICS } from "../utils/ics.js";

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { title, hostName, scheduledAt, durationMins, roomId, roomKeyHint } = req.body;
    const meeting = await Meeting.create({ title, hostName, scheduledAt, durationMins, roomId, roomKeyHint });
    res.json(meeting);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.get("/:roomId", async (req, res) => {
  const m = await Meeting.findOne({ roomId: req.params.roomId });
  if (!m) return res.status(404).json({ error: "Not found" });
  res.json(m);
});

router.get("/:roomId/ics", async (req, res) => {
  const m = await Meeting.findOne({ roomId: req.params.roomId });
  if (!m) return res.status(404).json({ error: "Not found" });

  const base = process.env.PUBLIC_BASE_URL || "http://localhost:5173";
  const url = `${base}/room/${encodeURIComponent(m.roomId)}`;
  const ics = await eventToICS({
    title: m.title,
    start: m.scheduledAt,
    durationMins: m.durationMins,
    description: `Join: ${url}`,
    url
  });
  res.setHeader("Content-Type", "text/calendar; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${m.roomId}.ics"`);
  res.send(ics);
});

export default router;
