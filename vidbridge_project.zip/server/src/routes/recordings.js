import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import Recording from "../models/Recording.js";

const router = express.Router();

const uploadDir = "/app/uploads";
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, Date.now() + "-" + file.originalname)
});
const upload = multer({ storage });

router.post("/upload", upload.single("recording"), async (req, res) => {
  const { meetingId } = req.body;
  const rec = await Recording.create({
    meetingId: meetingId || null,
    filename: req.file.filename,
    size: req.file.size,
    mimetype: req.file.mimetype
  });
  res.json({ ok: true, recordingId: rec._id });
});

router.get("/:id", async (req, res) => {
  const rec = await Recording.findById(req.params.id);
  if (!rec) return res.status(404).json({ error: "Not found" });
  const file = path.join(uploadDir, rec.filename);
  if (!fs.existsSync(file)) return res.status(404).json({ error: "Missing file" });
  res.setHeader("Content-Type", rec.mimetype);
  fs.createReadStream(file).pipe(res);
});

export default router;
