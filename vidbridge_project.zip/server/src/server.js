import dotenv from "dotenv";
dotenv.config();
import express from "express";
import http from "http";
import cors from "cors";
import morgan from "morgan";
import mongoose from "mongoose";
import { Server as IOServer } from "socket.io";
import meetingsRouter from "./routes/meetings.js";
import recordingsRouter from "./routes/recordings.js";

const app = express();
app.use(express.json());
app.use(morgan("dev"));
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") || "*" }));

const server = http.createServer(app);
const io = new IOServer(server, {
  cors: { origin: process.env.CORS_ORIGIN?.split(",") || "*" }
});

// Mongo
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/vidbridge";
mongoose.connect(MONGO_URI).then(() => console.log("Mongo connected")).catch(console.error);

// REST
app.use("/api/meetings", meetingsRouter);
app.use("/api/recordings", recordingsRouter);

app.get("/", (_, res) => res.json({ ok: true, name: "VidBridge Server" }));

// --- Signaling (Socket.IO) ---
io.on("connection", (socket) => {
  socket.on("join", ({ roomId, name }) => {
    socket.join(roomId);
    socket.to(roomId).emit("peer-joined", { id: socket.id, name });
    io.to(socket.id).emit("peers", Array.from(io.sockets.adapter.rooms.get(roomId) || []).filter(id => id !== socket.id));
  });

  socket.on("signal", ({ roomId, to, data }) => {
    io.to(to).emit("signal", { from: socket.id, data });
  });

  socket.on("chat", ({ roomId, message, name }) => {
    io.to(roomId).emit("chat", { from: name, message, ts: Date.now() });
  });

  socket.on("leave", ({ roomId }) => {
    socket.leave(roomId);
    socket.to(roomId).emit("peer-left", { id: socket.id });
  });

  socket.on("disconnecting", () => {
    for (const roomId of socket.rooms) {
      if (roomId !== socket.id) {
        socket.to(roomId).emit("peer-left", { id: socket.id });
      }
    }
  });
});

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => console.log("Server listening on " + PORT));
