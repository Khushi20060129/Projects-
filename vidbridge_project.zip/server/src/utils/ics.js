import { createEvent } from "ics";

export function eventToICS({ title, start, durationMins, description, url, location }) {
  const startDate = new Date(start);
  const event = {
    title,
    start: [startDate.getFullYear(), startDate.getMonth() + 1, startDate.getDate(), startDate.getHours(), startDate.getMinutes()],
    duration: { minutes: durationMins || 60 },
    description: description || "",
    location: location || "Online",
    url
  };
  return new Promise((resolve, reject) => {
    createEvent(event, (error, value) => {
      if (error) return reject(error);
      resolve(value);
    });
  });
}
