import React, { useEffect, useState } from "react";
import { SERVER_URL } from "../lib/api";

export default function Playback() {
  const [recordingId, setRecordingId] = useState("");
  const [source, setSource] = useState("");

  useEffect(()=>{
    const id = window.location.pathname.split("/").pop();
    setRecordingId(id || "");
    if (id) setSource(`${SERVER_URL}/api/recordings/${id}`);
  }, []);

  if (!recordingId) return <div>Invalid recording.</div>;

  return (
    <div style={{ padding: 16 }}>
      <h2>Recording Playback</h2>
      <video src={source} controls style={{ width: "100%", maxWidth: 900 }} />
    </div>
  );
}
