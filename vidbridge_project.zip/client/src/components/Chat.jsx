import React, { useState, useEffect, useRef } from "react";

export default function Chat({ socket, roomId, name }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const endRef = useRef();

  useEffect(() => {
    if (!socket) return;
    const onChat = (msg) => setMessages(m => [...m, msg]);
    socket.on("chat", onChat);
    return () => socket.off("chat", onChat);
  }, [socket]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const send = () => {
    if (!input.trim()) return;
    socket.emit("chat", { roomId, message: input, name });
    setInput("");
  };

  return (
    <div style={{ borderLeft: "1px solid #ddd", padding: 8, width: 280, display: "flex", flexDirection: "column", height: "100%" }}>
      <div style={{ flex: 1, overflowY: "auto" }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 6 }}><b>{m.from}:</b> {m.message}</div>
        ))}
        <div ref={endRef} />
      </div>
      <div style={{ display: "flex", gap: 6 }}>
        <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Type message..." style={{ flex: 1 }} />
        <button onClick={send}>Send</button>
      </div>
    </div>
  );
}
