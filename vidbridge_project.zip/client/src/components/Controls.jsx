import React from "react";

export default function Controls({ onToggleMic, onToggleCam, onScreenShare, onRecord, onStopRecord, recording, setRoomKey, roomKey }) {
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      <button onClick={onToggleMic}>Mic</button>
      <button onClick={onToggleCam}>Camera</button>
      <button onClick={onScreenShare}>Share Screen</button>
      {!recording ? <button onClick={onRecord}>Start Recording</button> : <button onClick={onStopRecord}>Stop & Upload</button>}
      <input placeholder="Room Key (E2EE)" value={roomKey} onChange={e=>setRoomKey(e.target.value)} style={{ width: 180 }} />
    </div>
  );
}
