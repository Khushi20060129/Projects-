import React, { useEffect, useRef, useState } from "react";
import { createSignaling, getMedia, createPeer } from "../lib/webrtc";
import { wrapSenderTrack, wrapReceiverTrack } from "../lib/e2ee";
import { SERVER_URL } from "../lib/api";
import Chat from "./Chat";
import Controls from "./Controls";

export default function VideoRoom({ roomId, name }) {
  const [socket, setSocket] = useState(null);
  const [peers, setPeers] = useState({}); // id -> RTCPeerConnection
  const [streams, setStreams] = useState({}); // id -> MediaStream
  const [localStream, setLocalStream] = useState(null);
  const [roomKey, setRoomKey] = useState("");
  const [recording, setRecording] = useState(false);
  const mediaRecorderRef = useRef();
  const recordedChunksRef = useRef([]);

  const localVideoRef = useRef();

  useEffect(() => {
    const s = createSignaling();
    setSocket(s);
    s.emit("join", { roomId, name });

    s.on("peers", async (peerIds) => {
      for (const pid of peerIds) await callPeer(pid);
    });

    s.on("peer-joined", async ({ id }) => {
      await callPeer(id);
    });

    s.on("signal", async ({ from, data }) => {
      const pc = peers[from] || await acceptPeer(from);
      if (data.sdp) {
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
        if (pc.signalingState === "have-remote-offer") {
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          s.emit("signal", { roomId, to: from, data: { sdp: pc.localDescription } });
        }
      } else if (data.candidate) {
        try { await pc.addIceCandidate(new RTCIceCandidate(data.candidate)); } catch (e) { console.warn(e); }
      }
    });

    s.on("peer-left", ({ id }) => {
      peers[id]?.close();
      setPeers(p => { const n = { ...p }; delete n[id]; return n; });
      setStreams(str => { const n = { ...str }; delete n[id]; return n; });
    });

    return () => {
      s.emit("leave", { roomId });
      s.disconnect();
      Object.values(peers).forEach(pc => pc.close());
    };
  }, []); // eslint-disable-line

  useEffect(() => {
    (async () => {
      const ms = await getMedia(false);
      setLocalStream(ms);
      if (localVideoRef.current) localVideoRef.current.srcObject = ms;
    })();
  }, []);

  async function callPeer(pid) {
    const pc = createPeer();
    setPeers(p => ({ ...p, [pid]: pc }));

    localStream?.getTracks().forEach(async (t) => {
      const sender = pc.addTrack(t, localStream);
      if (roomKey) await wrapSenderTrack(sender, roomKey);
    });

    pc.onicecandidate = (e) => {
      if (e.candidate) socket.emit("signal", { roomId, to: pid, data: { candidate: e.candidate } });
    };

    pc.ontrack = async (e) => {
      const [stream] = e.streams;
      setStreams(s => ({ ...s, [pid]: stream }));
      if (roomKey) {
        pc.getReceivers().forEach(r => wrapReceiverTrack(r, roomKey));
      }
    };

    const dc = pc.createDataChannel("chat");
    dc.onopen = () => {};
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit("signal", { roomId, to: pid, data: { sdp: pc.localDescription } });
  }

  async function acceptPeer(pid) {
    const pc = createPeer();
    setPeers(p => ({ ...p, [pid]: pc }));

    localStream?.getTracks().forEach(async (t) => {
      const sender = pc.addTrack(t, localStream);
      if (roomKey) await wrapSenderTrack(sender, roomKey);
    });

    pc.onicecandidate = (e) => {
      if (e.candidate) socket.emit("signal", { roomId, to: pid, data: { candidate: e.candidate } });
    };

    pc.ontrack = async (e) => {
      const [stream] = e.streams;
      setStreams(s => ({ ...s, [pid]: stream }));
      if (roomKey) {
        pc.getReceivers().forEach(r => wrapReceiverTrack(r, roomKey));
      }
    };

    pc.ondatachannel = (e) => {
      const dc = e.channel;
      dc.onmessage = (ev) => {};
    };

    return pc;
  }

  const onToggleMic = () => {
    localStream?.getAudioTracks().forEach(t => t.enabled = !t.enabled);
  };
  const onToggleCam = () => {
    localStream?.getVideoTracks().forEach(t => t.enabled = !t.enabled);
  };
  const onScreenShare = async () => {
    const ss = await getMedia(true);
    const vtrack = ss.getVideoTracks()[0];
    const sender = Object.values(peers)[0]?.getSenders().find(s => s.track && s.track.kind === "video");
    if (sender && vtrack) await sender.replaceTrack(vtrack);
    vtrack.onended = async () => {
      const cam = localStream.getVideoTracks()[0];
      if (sender && cam) await sender.replaceTrack(cam);
    };
  };

  const onRecord = () => {
    const combined = new MediaStream();
    localStream?.getTracks().forEach(t => combined.addTrack(t));
    Object.values(streams).forEach(s => s.getTracks().forEach(t => combined.addTrack(t)));
    const mr = new MediaRecorder(combined, { mimeType: "video/webm; codecs=vp8,opus" });
    mediaRecorderRef.current = mr;
    recordedChunksRef.current = [];
    mr.ondataavailable = (e) => { if (e.data.size) recordedChunksRef.current.push(e.data); };
    mr.onstop = async () => {
      const blob = new Blob(recordedChunksRef.current, { type: "video/webm" });
      const fd = new FormData();
      fd.append("recording", blob, `meeting-${roomId}.webm`);
      const res = await fetch(`${SERVER_URL}/api/recordings/upload`, { method: "POST", body: fd });
      const data = await res.json();
      alert(`Uploaded! Playback URL: /play/${data.recordingId}`);
    };
    mr.start(1000);
    setRecording(true);
  };
  const onStopRecord = () => {
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 300px", height: "calc(100vh - 80px)", gap: 8 }}>
      <div style={{ display: "grid", gap: 8, gridTemplateRows: "auto 1fr auto" }}>
        <div><Controls onToggleMic={onToggleMic} onToggleCam={onToggleCam} onScreenShare={onScreenShare} onRecord={onRecord} onStopRecord={onStopRecord} recording={recording} roomKey={roomKey} setRoomKey={setRoomKey} /></div>
        <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
          <video ref={localVideoRef} autoPlay muted playsInline style={{ width: "100%", background: "#000", borderRadius: 8 }} />
          {Object.entries(streams).map(([id, stream]) => (
            <video key={id} autoPlay playsInline style={{ width: "100%", background: "#000", borderRadius: 8 }} ref={el => { if (el && stream) el.srcObject = stream; }} />
          ))}
        </div>
        <div style={{ fontSize: 12, color: "#666" }}>Room: {roomId} — You are: {name}</div>
      </div>
      <Chat socket={socket} roomId={roomId} name={name} />
    </div>
  );
}
