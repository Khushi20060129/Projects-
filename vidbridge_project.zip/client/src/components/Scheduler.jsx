import React, { useState } from "react";
import { createMeeting } from "../lib/api";
import { SERVER_URL } from "../lib/api";

export default function Scheduler({ onScheduled }) {
  const [title, setTitle] = useState("Team Sync");
  const [host, setHost] = useState("Host");
  const [date, setDate] = useState(() => new Date().toISOString().slice(0,16));
  const [duration, setDuration] = useState(60);
  const [roomId, setRoomId] = useState(() => Math.random().toString(36).slice(2,8));
  const [roomKeyHint, setRoomKeyHint] = useState("set-a-key");

  const schedule = async () => {
    const scheduledAt = new Date(date).toISOString();
    const m = await createMeeting({ title, hostName: host, scheduledAt, durationMins: Number(duration), roomId, roomKeyHint });
    onScheduled(m);
  };

  return (
    <div style={{ display: "grid", gap: 8, maxWidth: 420 }}>
      <h3>Schedule a Meeting</h3>
      <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" />
      <input value={host} onChange={e=>setHost(e.target.value)} placeholder="Host name" />
      <label>Start</label>
      <input type="datetime-local" value={date} onChange={e=>setDate(e.target.value)} />
      <label>Duration (mins)</label>
      <input type="number" value={duration} onChange={e=>setDuration(e.target.value)} />
      <label>Room ID</label>
      <input value={roomId} onChange={e=>setRoomId(e.target.value)} />
      <label>Room Key Hint (E2EE)</label>
      <input value={roomKeyHint} onChange={e=>setRoomKeyHint(e.target.value)} />
      <button onClick={schedule}>Create</button>
      <div style={{ fontSize: 12, color: "#666" }}>After creating, you can download ICS or add to Google Calendar.</div>
    </div>
  );
}
