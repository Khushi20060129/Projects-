import React, { useEffect, useState } from "react";
import Scheduler from "./components/Scheduler";
import VideoRoom from "./components/VideoRoom";
import Playback from "./components/Playback";
import { getMeeting, SERVER_URL } from "./lib/api";

export default function App() {
  const [route, setRoute] = useState(window.location.pathname);
  const [meeting, setMeeting] = useState(null);
  const [name, setName] = useState("Guest");

  useEffect(() => {
    const onPop = () => setRoute(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  useEffect(() => {
    if (route.startsWith("/room/")) {
      const roomId = route.split("/").pop();
      getMeeting(roomId).then(setMeeting).catch(()=>setMeeting({ roomId, title: "Ad-hoc Meeting", durationMins: 60 }));
    }
  }, [route]);

  if (route.startsWith("/play/")) return <Playback />;

  if (route.startsWith("/room/")) {
    const roomId = route.split("/").pop();
    return (
      <div>
        <Header setRoute={setRoute} />
        <div style={{ padding: 12 }}>
          <div style={{ marginBottom: 8 }}>
            <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" />
            <a style={{ marginLeft: 12 }} href={`${SERVER_URL}/api/meetings/${roomId}/ics`}>Download ICS</a>
            <a style={{ marginLeft: 12 }} href={`https://calendar.google.com/calendar/u/0/r/eventedit?text=${encodeURIComponent(meeting?.title || "Meeting")}&details=${encodeURIComponent(window.location.href)}&dates=`}>Add to Google (prefill)</a>
          </div>
          <VideoRoom roomId={roomId} name={name} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <Header setRoute={setRoute} />
      <div style={{ padding: 12 }}>
        <Scheduler onScheduled={(m)=>{ setMeeting(m); window.history.pushState({}, "", `/room/${m.roomId}`); setRoute(`/room/${m.roomId}`); }} />
      </div>
    </div>
  );
}

function Header({ setRoute }) {
  return (
    <div style={{ padding: 12, display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #eee" }}>
      <div style={{ fontWeight: 700 }}>VidBridge</div>
      <div style={{ display: "flex", gap: 12 }}>
        <a href="/" onClick={(e)=>{ e.preventDefault(); window.history.pushState({}, "", "/"); setRoute("/"); }}>Home</a>
        <a href="/play/demo" onClick={(e)=>{ e.preventDefault(); window.history.pushState({}, "", "/play/demo"); setRoute("/play/demo"); }}>Playback</a>
      </div>
    </div>
  );
}
